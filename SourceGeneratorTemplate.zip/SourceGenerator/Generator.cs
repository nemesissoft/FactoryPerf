﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Symbols.PublicModel;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.FindSymbols;
using Microsoft.CodeAnalysis.Text;

#nullable enable

namespace SourceGenerator
{
    [Generator]
    public class AutoFactoryGenerator : ISourceGenerator
    {
        internal const string AUTO_ATTRIBUTE_NAME = @"AutoFactoryAttribute";
        private const string AUTO_ATTRIBUTE_SOURCE = @"
using System;
using System.Diagnostics;

namespace Auto
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct, Inherited = false, AllowMultiple = false)]
    sealed class " + AUTO_ATTRIBUTE_NAME + @" : Attribute
    {
        public Type ServiceType { get; }

        public " + AUTO_ATTRIBUTE_NAME + @"(Type serviceType) => ServiceType = serviceType;
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct, Inherited = false, AllowMultiple = true)]
    sealed class ImplementationNameAttribute : Attribute
    {
        public string RegisterAs { get; }

        public ImplementationNameAttribute(string registerAs) => RegisterAs = registerAs;
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct, Inherited = false)]
    sealed class AlternativeRegistrationAttribute : Attribute
    {
        public AlternativeRegistrations RegisterBy { get; }

        public AlternativeRegistrationAttribute(AlternativeRegistrations registerBy) => RegisterBy = registerBy;
    }

    [Flags]
    public enum AlternativeRegistrations : byte
    {
        [Obsolete(""Used only as default value"", true)]
        [DebuggerBrowsable(DebuggerBrowsableState.Never)]
        None = 0, 
        TypeName = 1, 
        FullTypeName = 2,
        AssemblyQualifiedName = 4,
    }
}
";
        public void Initialize(GeneratorInitializationContext context) => context.RegisterForSyntaxNotifications(() => new AutoFactorySyntaxReceiver());

        public void Execute(GeneratorExecutionContext context)
        {
            //context.AddSource("generated.cs", "class Foo2 { }");

            //context.CheckDebugger(nameof(AutoFactoryGenerator));

            context.AddSource("AutoFactoryAttributes", SourceText.From(AUTO_ATTRIBUTE_SOURCE, Encoding.UTF8));

            if (context.SyntaxReceiver is not AutoFactorySyntaxReceiver receiver || context.Compilation is not CSharpCompilation cSharpCompilation) return;

            var options = cSharpCompilation.SyntaxTrees[0].Options as CSharpParseOptions;
            var compilation = context.Compilation.AddSyntaxTrees(
                CSharpSyntaxTree.ParseText(SourceText.From(AUTO_ATTRIBUTE_SOURCE, Encoding.UTF8), options)
            );

            if (!TryGetAttributes(compilation, context, out var autoAttributeSymbol, out var implementationNameAttributeSymbol, out var alternativeRegistrationAttributeSymbol)) return;

            foreach (var type in receiver.CandidateTypes)
            {
                var model = compilation.GetSemanticModel(type.SyntaxTree);

                if (!ShouldProcessType(type, model, autoAttributeSymbol, out INamedTypeSymbol serviceTypeSymbol) || serviceTypeSymbol is null) continue;

                Debugger.Launch();
                var list = ProcessTypes(compilation, serviceTypeSymbol);


                /*{
                    if (!typeSymbol.ContainingSymbol.Equals(typeSymbol.ContainingNamespace, SymbolEqualityComparer.Default))
                    {
                        ReportDiagnostics(context, NamespaceAndTypeNamesEqualRule, typeSymbol);
                        continue;
                    }

                    var namespaces = new HashSet<string> { "System", "Nemesis.TextParsers.Parsers", "Nemesis.TextParsers.Utils", "Nemesis.TextParsers" };
                    if (type.SyntaxTree.GetRoot() is CompilationUnitSyntax compilationUnit)
                    {
                        var sourceNamespacesWithoutUsing = compilationUnit.Usings.Select(u => u
                                .WithUsingKeyword(SyntaxFactory.MissingToken(SyntaxKind.UsingKeyword))
                                .WithSemicolonToken(SyntaxFactory.MissingToken(SyntaxKind.SemicolonToken))
                                .ToString())
                            .ToList();

                        foreach (var ns in sourceNamespacesWithoutUsing)
                            namespaces.Add(ns);
                    }

                    if (TryGetMembers(typeSymbol, context, namespaces, out var members) && members != null)
                    {
                        var settings = GeneratedDeconstructableSettings.FromDeconstructableSettingsAttribute(deconstructableSettingsAttributeData);

                        string typeModifiers = GetTypeModifiers(type);

                        string classSource = RenderRecord(typeSymbol, typeModifiers, members, settings, namespaces);
                        context.AddSource($"{typeSymbol.Name}_AutoDeconstructable.cs", SourceText.From(classSource, Encoding.UTF8));
                    }
                }*/
            }
        }

        private object ProcessTypes(Compilation compilation, INamedTypeSymbol serviceTypeSymbol)
        {
            bool isInterface = false;
            if (serviceTypeSymbol.TypeKind == TypeKind.Class) isInterface = false;
            else if (serviceTypeSymbol.TypeKind == TypeKind.Interface) isInterface = true;
            else
            {
                //TODO report Diagnostics
                return null;
            }

            bool DerivesFromClass(INamedTypeSymbol symbol)
            {
                var current = symbol;
                while (current != null)
                {
                    if (SymbolEqualityComparer.Default.Equals(current, serviceTypeSymbol))
                        return true;
                    current = current.BaseType;
                }
                return false;
            }

            bool ImplementsInterface(INamedTypeSymbol symbol) =>
                symbol.AllInterfaces.Any(i => SymbolEqualityComparer.Default.Equals(i, serviceTypeSymbol));

            var result = new List<INamedTypeSymbol>();

            foreach (var syntaxTree in compilation.SyntaxTrees)
            {
                var model = compilation.GetSemanticModel(syntaxTree);
                var classes = syntaxTree.GetRoot().DescendantNodes().OfType<ClassDeclarationSyntax>();

                foreach (var @class in classes)
                {
                    var classSymbol = model.GetDeclaredSymbol(@class);
                    if (classSymbol == null || classSymbol.IsAbstract || classSymbol.IsUnboundGenericType) continue;

                    if (isInterface && ImplementsInterface(classSymbol)
                        ||
                        !isInterface && DerivesFromClass(classSymbol)
                    )
                    {
                        //TODO check paramless ctors - 1 public 
                        result.Add(classSymbol);
                    }
                }
            }

            return result;
        }

        private bool TryGetAttributes(Compilation compilation, GeneratorExecutionContext context,
            out INamedTypeSymbol? autoAttributeSymbol,
            out INamedTypeSymbol? implementationNameAttributeSymbol,
            out INamedTypeSymbol? alternativeRegistrationAttributeSymbol
            )
        {
            autoAttributeSymbol = implementationNameAttributeSymbol = alternativeRegistrationAttributeSymbol = null;

            autoAttributeSymbol = compilation.GetTypeByMetadataName($"Auto.{AUTO_ATTRIBUTE_NAME}");
            if (autoAttributeSymbol is null)
            {
                //TODO ReportDiagnostics(context, NoAutoAttributeRule, null);
                return false;
            }
            implementationNameAttributeSymbol = compilation.GetTypeByMetadataName("Auto.ImplementationNameAttribute");
            if (implementationNameAttributeSymbol is null)
            {
                //TODO ReportDiagnostics
                return false;
            }

            alternativeRegistrationAttributeSymbol = compilation.GetTypeByMetadataName("Auto.AlternativeRegistrationAttribute");
            if (alternativeRegistrationAttributeSymbol is null)
            {
                //TODO ReportDiagnostics
                return false;
            }

            return true;
        }

        private static bool ShouldProcessType(TypeDeclarationSyntax type, SemanticModel model, INamedTypeSymbol autoAttributeSymbol, out INamedTypeSymbol? namedTypeSymbol)
        {
            static AttributeData? GetAttribute(ISymbol typeSymbol, ISymbol attributeSymbol) =>
                typeSymbol.GetAttributes().FirstOrDefault(ad =>
                    ad?.AttributeClass is { } @class && @class.Equals(attributeSymbol, SymbolEqualityComparer.Default));

            namedTypeSymbol = null;
            if (model.GetDeclaredSymbol(type) is { } ts && GetAttribute(ts, autoAttributeSymbol) is { } autoFactoryAttribute)
            {
                if (autoFactoryAttribute.ConstructorArguments is { Length: 1 } ctorArgs &&
                    ctorArgs[0] is { IsNull: false, Kind: TypedConstantKind.Type, Value: INamedTypeSymbol argValue })
                {
                    namedTypeSymbol = argValue;
                    return true;
                }
                else
                {
                    //TODO report Diagnostics
                }
            }

            return false;
        }

        class AutoFactorySyntaxReceiver : ISyntaxReceiver
        {
            public List<TypeDeclarationSyntax> CandidateTypes { get; } = new();

            public void OnVisitSyntaxNode(SyntaxNode syntaxNode)
            {
                if (syntaxNode is TypeDeclarationSyntax tds && tds.AttributeLists.Count > 0)
                    CandidateTypes.Add(tds);
            }
        }
    }
}
